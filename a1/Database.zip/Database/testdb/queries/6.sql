--6.sql: change the statement below.

SELECT *
FROM faculty;
