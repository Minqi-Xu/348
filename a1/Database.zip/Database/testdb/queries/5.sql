--5.sql: change the statement below.

SELECT COUNT(*)
FROM student;
