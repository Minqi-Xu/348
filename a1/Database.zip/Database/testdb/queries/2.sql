--2.sql: change the statement below.

SELECT *
FROM class;
