--1.sql: change the statement below.

SELECT Sum(age)/count(*) 
FROM student;
